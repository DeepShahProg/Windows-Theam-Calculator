let currentOperand = '';
let previousOperand = '';
let operation = null;

document.addEventListener('keydown', handleKeyboardInput);

function appendNumber(number) {
    if (number === '±') {
        currentOperand = (parseFloat(currentOperand) * -1).toString();
    } else if (number === '%') {
        currentOperand = (parseFloat(currentOperand) / 100).toString();
    } else {
        if (currentOperand.includes('.') && number === '.') return;
        currentOperand += number;
    }
    updateDisplay();
}

function chooseOperation(op) {
    if (currentOperand === '') return;
    if (previousOperand !== '') {
        calculate();
    }
    operation = op;
    previousOperand = currentOperand;
    currentOperand = '';
    updateDisplay();
}

function calculate() {
    let computation;
    const prev = parseFloat(previousOperand);
    const current = parseFloat(currentOperand);
    if (isNaN(prev) || isNaN(current)) return;
    switch (operation) {
        case '+':
            computation = prev + current;
            break;
        case '-':
            computation = prev - current;
            break;
        case '*':
            computation = prev * current;
            break;
        case '/':
            computation = prev / current;
            break;
        default:
            return;
    }
    currentOperand = computation.toString();
    operation = null;
    previousOperand = '';
    updateDisplay();
}

function clearAll() {
    currentOperand = '';
    previousOperand = '';
    operation = null;
    updateDisplay();
}

function updateDisplay() {
    document.getElementById('result').innerText = currentOperand || '0';
    document.getElementById('operation').innerText = previousOperand + ' ' + (operation || '') + ' ' + currentOperand;
}

function handleKeyboardInput(event) {
    if (event.key >= 0 && event.key <= 9) {
        appendNumber(event.key);
    }
    if (event.key === '.') {
        appendNumber('.');
    }
    if (event.key === '=' || event.key === 'Enter') {
        calculate();
    }
    if (event.key === 'Backspace') {
        currentOperand = currentOperand.slice(0, -1);
        updateDisplay();
    }
    if (event.key === 'Escape') {
        clearAll();
    }
    if (event.key === '+' || event.key === '-' || event.key === '*' || event.key === '/') {
        chooseOperation(event.key);
    }
}

function toggleSign() {
    currentOperand = (parseFloat(currentOperand) * -1).toString();
    updateDisplay();
}